using Microsoft.VisualStudio.TestTools.UnitTesting;
using FunctionLibrary;

namespace FunctionCalculatorTests
{
    [TestClass]
    public class FunctionCalculatorTests
    {
        [TestMethod]
        public void TestDivisionByZero()
        {
            FunctionCalculator calculator = new FunctionCalculator();
            double result = calculator.CalculateFunction(0, 5);
            Assert.AreEqual(double.PositiveInfinity, result);
        }

        [TestMethod]
        public void TestOutOfRange()
        {
            FunctionCalculator calculator = new FunctionCalculator();
            double result = calculator.CalculateFunction(2, 20);
            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void TestNormalCase1()
        {
            FunctionCalculator calculator = new FunctionCalculator();
            double result = calculator.CalculateFunction(1, 3);
            Assert.AreEqual(double.PositiveInfinity, result);
        }

        [TestMethod]
        public void TestNormalCase2()
        {
            FunctionCalculator calculator = new FunctionCalculator();
            double result = calculator.CalculateFunction(3, 4);
            Assert.AreEqual(-1, result);
        }

        [TestMethod]
        public void TestNormalCase3()
        {
            FunctionCalculator calculator = new FunctionCalculator();
            double result = calculator.CalculateFunction(5, 2);
            Assert.AreEqual(-0.5, result);
        }
    }
}