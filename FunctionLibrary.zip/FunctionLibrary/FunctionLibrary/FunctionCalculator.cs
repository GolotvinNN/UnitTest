﻿using System;

namespace FunctionLibrary
{
    public class FunctionCalculator
    {
        public double CalculateFunction(double N, int iterations)
        {
            double result = 0;
            double x = 0;

            try
            {
                for (int i = 0; i < iterations; i++)
                {
                    if (Math.Abs(x - N) < 0.0001)
                    {
                        throw new ArgumentOutOfRangeException("x слишком близко к N");
                    }

                    result = 1 / (x - N);
                    Console.WriteLine($"f({x}) = {result}");
                    x += 0.1;
                }
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Диление на 0");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Вычесление завершено");
            }

            return result;
        }
    }
}